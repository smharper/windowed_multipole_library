MIT Computational Reactor Physics Group windowed multipole nuclear data library
version 0.2

Warning: this data is experimental and its accuracy is not guaranteed for any
purpose.  It is provided only for the purposes of regression testing OpenMC's
windowed multipole capability.

For further information see,
C. Josey, P. Ducru, B. Forget, K. Smith, Windowed Multipole for Cross Section
Doppler Broadening, Journal of Computational Physics, Volume 307, 15 February
2016, Pages 715-727, ISSN 0021-9991,
http://dx.doi.org/10.1016/j.jcp.2015.08.013.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
